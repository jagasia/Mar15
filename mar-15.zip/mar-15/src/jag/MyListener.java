package jag;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * Application Lifecycle Listener implementation class MyListener
 *
 */
@WebListener
public class MyListener implements HttpSessionListener, HttpSessionAttributeListener {

    /**
     * Default constructor. 
     */
    public MyListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see HttpSessionListener#sessionCreated(HttpSessionEvent)
     */
    public void sessionCreated(HttpSessionEvent se)  { 
         Date dt=new Date();
         SimpleDateFormat sdf=new SimpleDateFormat("HH:mm:ss");
         System.out.println("A session was created at "+sdf.format(dt));
    }

	/**
     * @see HttpSessionListener#sessionDestroyed(HttpSessionEvent)
     */
    public void sessionDestroyed(HttpSessionEvent se)  { 
    	Date dt=new Date();
        SimpleDateFormat sdf=new SimpleDateFormat("HH:mm:ss");
        System.out.println("A session was destroyed at "+sdf.format(dt));
    }

	@Override
	public void attributeAdded(HttpSessionBindingEvent event) {
		System.out.printf("An attribute %s added with value %s",event.getName(),event.getValue());
	}

	@Override
	public void attributeRemoved(HttpSessionBindingEvent event) {
		System.out.printf("An attribute named %s is removed",event.getName());
	}

	@Override
	public void attributeReplaced(HttpSessionBindingEvent event) {
		// TODO Auto-generated method stub
		HttpSessionAttributeListener.super.attributeReplaced(event);
	}
	
}
